#!/usr/bin/python
# -*- coding: utf-8 -*-
# flake8: noqa

print "abc"