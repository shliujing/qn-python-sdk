# -*- coding: utf-8 -*-

print(range(0, 30, 5))
